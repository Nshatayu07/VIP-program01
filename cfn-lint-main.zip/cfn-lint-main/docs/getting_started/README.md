# Getting started
This section contains guides on developing with and for `cfn-lint`.

## Integrate cfn-lint (API)
Apart from CLI usage, `cfn-lint` can also be integrated in an existing codebase.
See the [integration](integration.md) documentation on how to set up this integration.

## Creating rules
See the [rules](rules.md) documentation on how to create new rules.
